/*
 * hello.c - Canonical "Hello, World!" program
 */
#include <stdio.h>
#include "helper.h"

int main(void)
{
	printf("Hello, Linux programming world!\n");
	msg();
	return 0;
}

