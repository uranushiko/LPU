#include <stdio.h>

int main(void)
{
	char msg[] = "Hello, Linux programmer!";

	puts(msg);
	printf("Here you are, using diff.\n");

	return 0;
}

