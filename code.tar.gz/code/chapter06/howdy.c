#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	char msg[] = "Hello, Linux programmer, from howdy.c!";

	puts(msg);
	printf("howdy.c says, `Here you are, using diff.'\n");

	exit(EXIT_SUCCESS);
}

